package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Settings
import com.example.model.AppScreen
import com.example.model.BluetoothPeerDevice
import com.example.model.BluetoothState
import com.example.model.ChunkSizeOption
import com.example.model.DiscoveredPeerSession
import com.example.model.IncomingConnectionRequest
import com.example.model.ReceiverConnectionPhase
import com.example.model.TransferFileItem
import com.example.model.TransportMode
import com.example.network.BluetoothP2PManager
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.QrCodeCanvas
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightCardElevated
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.util.QrCodeGenerator
import com.example.viewmodel.P2PUiState
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SendFilesScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onNavigateToCategory: (AppScreen) -> Unit,
    onPickFiles: (List<Uri>) -> Unit,
    onPickEntireFolder: (Uri) -> Unit = {},
    onRemoveFolderBatch: (String) -> Unit = {},
    onRemoveFile: (String) -> Unit,
    onRegenerateCode: () -> Unit,
    onSelectChunkSize: (ChunkSizeOption) -> Unit,
    onStartSending: () -> Unit,
    onStopSendSession: () -> Unit = {},
    onApproveReceiver: () -> Unit = {},
    onRejectReceiver: () -> Unit = {},
    onOpenLiveTransferScreen: () -> Unit = {},
    onToggleSelectFolderInSend: (String) -> Unit = {},
    onAddSelectedFoldersToQueue: () -> Unit = {},
    onSelectTransportMode: (TransportMode) -> Unit = {},
    onStartBluetoothDiscovery: () -> Unit = {},
    onPairBluetoothDevice: (BluetoothPeerDevice) -> Unit = {},
    onOpenBluetoothSettings: () -> Unit = {},
    onBluetoothPermissionsResult: (Map<String, Boolean>) -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val multiFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onPickFiles(uris)
        }
    }

    val folderTreePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            onPickEntireFolder(treeUri)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            ScreenTopBar(
                title = "إرسال ملفات ومجلدات وتطبيقات",
                subtitle = "اختر ملفات أو مجلدات كاملة ثم اضغط بدء جلسة الإرسال",
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Short Connection Code + QR Code + Session Lifecycle Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(MidnightSurface)
                    .border(
                        width = 1.4.dp,
                        color = if (uiState.isSenderReady) NeonEmerald.copy(alpha = 0.75f) else ElectricCyan.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .padding(18.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "جلسة الإرسال وكود الربط",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextSecondary
                        )
                        Surface(
                            color = if (uiState.isSenderReady) NeonEmerald.copy(alpha = 0.2f) else HotspotAmber.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(
                                text = uiState.senderSessionPhase.arabicLabel,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (uiState.isSenderReady) NeonEmerald else HotspotAmber,
                                modifier = Modifier
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                                    .testTag("sender_session_phase_badge")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF070E1B))
                            .border(1.dp, ElectricCyan.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = uiState.connectionCode,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            color = ElectricCyan,
                            modifier = Modifier.testTag("sender_short_code_text")
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        IconButton(
                            onClick = {
                                val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                cb?.setPrimaryClip(ClipData.newPlainText("BarqSher Code", uiState.connectionCode))
                            },
                            modifier = Modifier.testTag("copy_code_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = "نسخ كود الاتصال",
                                tint = ElectricCyan
                            )
                        }
                        IconButton(
                            onClick = onRegenerateCode,
                            modifier = Modifier.testTag("regenerate_code_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "تحديث الكود",
                                tint = HotspotAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Session ID & Expiration Timer Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0B1526))
                            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "معرّف الجلسة: ${uiState.sessionId}",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                color = Color.White,
                                modifier = Modifier.testTag("sender_session_id_text")
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Timer,
                                contentDescription = null,
                                tint = if (uiState.isSenderReady) NeonEmerald else TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (uiState.isSenderReady) {
                                    "الصلاحية: ${uiState.formattedSessionRemainingTime}"
                                } else {
                                    "تُفعّل عند بدء الجلسة (10:00)"
                                },
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (uiState.isSenderReady) NeonEmerald else TextSecondary,
                                modifier = Modifier.testTag("send_session_countdown_text")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    QrCodeCanvas(
                        content = uiState.qrPayload,
                        size = 186.dp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "العنوان المحلي: ${uiState.networkStatus.localIp}:${uiState.networkStatus.port} (${uiState.networkStatus.networkTypeLabel})",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = NeonEmerald,
                        textAlign = TextAlign.Center
                    )

                    if (uiState.isSenderReady) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0A2924))
                                .border(1.dp, NeonEmerald.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                .padding(10.dp)
                                .testTag("active_send_session_waiting_box")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "🔒 الجلسة نشطة ومؤمّنة: النقل متوقف لحين اتصال المستلم وموافقتك على طلب الاتصال",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = NeonEmerald,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OutlinedButton(
                                        onClick = onStopSendSession,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("stop_send_session_button")
                                    ) {
                                        Icon(Icons.Filled.Cancel, contentDescription = null, tint = CoralRose, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إلغاء / إيقاف الجلسة", color = CoralRose, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Button(
                                        onClick = onOpenLiveTransferScreen,
                                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("open_live_transfer_from_send_button")
                                    ) {
                                        Icon(Icons.Filled.Speed, contentDescription = null, tint = Color(0xFF002229), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("شاشة النقل الحي", color = Color(0xFF002229), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            BluetoothAndTransportModeCard(
                uiState = uiState,
                isReceiveScreen = false,
                onSelectTransportMode = onSelectTransportMode,
                onStartBluetoothDiscovery = onStartBluetoothDiscovery,
                onPairBluetoothDevice = onPairBluetoothDevice,
                onConnectBluetoothPeer = {},
                onOpenBluetoothSettings = onOpenBluetoothSettings,
                onBluetoothPermissionsResult = onBluetoothPermissionsResult
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Category Browsers to add Installed Apps, Photos, Videos, Audio, or Files
            Text(
                text = "تصفح وإضافة من مدير الملفات الداخلي وأقسام الهاتف:",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.FILES) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("send_open_internal_file_manager_button")
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = HotspotAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("مدير الملفات والمجلدات الداخلي", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.APPS) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("send_pick_from_apps_button")
                ) {
                    Icon(Icons.Filled.Android, contentDescription = null, tint = NeonEmerald, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("التطبيقات (${uiState.installedApps.size})", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.IMAGES) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Image, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الصور", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.VIDEOS) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Movie, contentDescription = null, tint = CoralRose, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الفيديوهات", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.AUDIO) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color(0xFFEC4899), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الصوتيات", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { folderTreePickerLauncher.launch(null) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("send_pick_saf_tree_button")
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = NeonEmerald, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("مجلد SAF خارجي", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { multiFilePickerLauncher.launch(arrayOf("*/*")) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("send_pick_saf_files_button")
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ملفات SAF متعددة", fontSize = 12.sp, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Open In-App Folders & Files Selection Screen (with selection circles next to folders & files)
            Button(
                onClick = {
                    onNavigateToCategory(AppScreen.FILES)
                },
                enabled = !uiState.isScanningFolder,
                colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("send_pick_entire_folder_button")
            ) {
                if (uiState.isScanningFolder) {
                    CircularProgressIndicator(
                        color = Color(0xFF1F1200),
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "جاري تجهيز المجلدات والملفات المحددة...",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF1F1200),
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Folder,
                        contentDescription = null,
                        tint = Color(0xFF1F1200)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "فتح مدير الملفات والمجلدات الداخلي (تحديد ملفات ومجلدات كاملة)",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF1F1200),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Direct In-Page Folder Selection Preview on Send Screen
            if (uiState.storageFolders.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                        .testTag("send_quick_folders_browser_card")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "مجلدات الجهاز السريعة (حدد مجلداً كاملاً للإرسال):",
                                style = MaterialTheme.typography.labelLarge,
                                color = HotspotAmber,
                                fontWeight = FontWeight.Bold
                            )
                            if (uiState.selectedFolderPaths.isNotEmpty()) {
                                Button(
                                    onClick = onAddSelectedFoldersToQueue,
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("send_add_quick_selected_folders_button")
                                ) {
                                    Text(
                                        text = "إضافة المحدد (${uiState.selectedFolderPaths.size})",
                                        color = Color(0xFF002418),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        uiState.storageFolders.take(4).forEach { folder ->
                            val isSelected = folder.path in uiState.selectedFolderPaths
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) HotspotAmber.copy(alpha = 0.16f) else Color(0xFF0B1424))
                                    .border(
                                        1.dp,
                                        if (isSelected) HotspotAmber else GlassBorder,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { onToggleSelectFolderInSend(folder.path) }
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                        contentDescription = "تحديد ${folder.relativeDisplayPath}",
                                        tint = if (isSelected) HotspotAmber else TextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.Filled.Folder,
                                        contentDescription = null,
                                        tint = HotspotAmber,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = folder.relativeDisplayPath,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${folder.fileCount} ملف • ${folder.subfolderCount} مجلد فرعي • ${formatBytesArabic(folder.totalBytes)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Chunk Size Selector
            Text(
                text = "حجم الدفعة (Chunking) المتكيف مع الشبكة:",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ChunkSizeOption.entries.forEach { option ->
                    val selected = option == uiState.selectedChunkSize
                    Surface(
                        color = if (selected) ElectricCyan.copy(alpha = 0.22f) else MidnightCard,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) ElectricCyan else GlassBorder
                        ),
                        modifier = Modifier
                            .clickable { onSelectChunkSize(option) }
                            .testTag("chunk_option_${option.name}")
                    ) {
                        Text(
                            text = option.label,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp,
                            color = if (selected) ElectricCyan else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Unified Send Queue Header (Each selected folder counts as 1 transfer unit alongside standalone files)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "قائمة الإرسال المحددة (${uiState.totalSelectedUnitsInSendQueue} عنصر)",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    modifier = Modifier.testTag("send_queue_units_count_label")
                )
                Text(
                    text = "الإجمالي: ${formatBytesArabic(uiState.totalBytes)} • ${uiState.totalChunksCount} دفعة",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.sp,
                    color = ElectricCyan,
                    modifier = Modifier.testTag("send_queue_total_bytes_label")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.files.isEmpty() && uiState.folderBatches.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                        .padding(24.dp)
                ) {
                    Text(
                        text = "قائمة الإرسال فارغة. اضغط «فتح مدير الملفات والمجلدات الداخلي» أعلاه لتحديد أي مجلد مثل (Download/ropon) أو عدة مجلدات وملفات معاً عبر دائرة الاختيار ثم إرسالها.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // 1. Render each selected Folder as a single unified transfer item in the queue
                uiState.folderBatches.forEach { batch ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF211709))
                            .border(1.2.dp, HotspotAmber.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                            .testTag("folder_batch_card_${batch.batchId}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(HotspotAmber.copy(alpha = 0.2f))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Folder,
                                    contentDescription = null,
                                    tint = HotspotAmber,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "مجلد كامل: ${batch.rootFolderName} (${batch.sourceUriOrPath})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "عنصر نقل واحد يشمل: ${batch.totalFilesCount} ملف • ${batch.totalSubfoldersCount} مجلد فرعي (${batch.emptyFoldersCount} فارغ) • ${formatBytesArabic(batch.totalBytes)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFFDE68A)
                                )
                            }
                        }
                        IconButton(onClick = { onRemoveFolderBatch(batch.batchId) }) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "إزالة المجلد بالكامل",
                                tint = CoralRose
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // 2. Render standalone selected files alongside the unified folder items
                uiState.standaloneFilesInQueue.forEach { item ->
                    SelectedFileQueueRow(
                        item = item,
                        onRemove = { onRemoveFile(item.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Start Live Send Session CTA
            Button(
                onClick = onStartSending,
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("start_live_sending_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Send,
                    contentDescription = null,
                    tint = Color(0xFF002418)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (uiState.isSenderReady) {
                        "تحديث وتجديد جلسة الإرسال النشطة (${uiState.formattedSessionRemainingTime})"
                    } else {
                        "بدء جلسة الإرسال وتوليد رمز QR للمستلم"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFF002418),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        CopyrightFooter()
    }

    // Incoming Receiver Connection Approval Dialog on Sender Device
    uiState.incomingConnectionRequest?.let { req ->
        IncomingConnectionRequestDialog(
            request = req,
            onApprove = onApproveReceiver,
            onReject = onRejectReceiver
        )
    }
}

@Composable
fun IncomingConnectionRequestDialog(
    request: IncomingConnectionRequest,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onReject,
        containerColor = MidnightCardElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Security,
                    contentDescription = null,
                    tint = NeonEmerald,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "طلب اتصال وارد لاستلام الملفات",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.testTag("incoming_connection_request_dialog")
            ) {
                Text(
                    text = "يرغب الجهاز التالي بالاتصال بجلسة الإرسال الحالية وتنزيل العناصر المحددة:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MidnightCard)
                        .border(1.dp, NeonEmerald.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "📱 اسم الجهاز المستلم: ${request.clientDeviceName}",
                            style = MaterialTheme.typography.titleMedium,
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "🌐 عنوان الشبكة (IP): ${request.clientIp}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            color = ElectricCyan
                        )
                        Text(
                            text = "📦 العناصر المطلوبة: ${request.requestedFilesCount} عنصر • ${formatBytesArabic(request.totalBytes)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = HotspotAmber
                        )
                    }
                }
                Text(
                    text = "لن يبدأ نقل أي ملف إلا بعد ضغطك على «موافقة وبدء النقل».",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onApprove,
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("approve_receiver_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF002418),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "موافقة وبدء النقل",
                    color = Color(0xFF002418),
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onReject,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("reject_receiver_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = null,
                    tint = CoralRose,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "رفض الاتصال",
                    color = CoralRose,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    )
}

@Composable
private fun SelectedFileQueueRow(
    item: TransferFileItem,
    onRemove: () -> Unit
) {
    val badgeColor = Color(item.category.badgeColorHex)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightCard)
            .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeColor.copy(alpha = 0.18f))
            ) {
                Icon(
                    imageVector = categoryIcon(item.category),
                    contentDescription = item.category.arabicLabel,
                    tint = badgeColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.displayPathOrName,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = badgeColor.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = item.fileExtensionBadge,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = badgeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = if (item.isDirectory) {
                        "مجلد فرعي فارغ داخل (${item.rootFolderName}) • يُعاد إنشاؤه تلقائياً"
                    } else if (item.rootFolderName.isNotBlank()) {
                        "ضمن مجلد (${item.rootFolderName}) • ${item.category.arabicLabel} • ${formatBytesArabic(item.sizeBytes)}"
                    } else {
                        "${item.category.arabicLabel} • ${formatBytesArabic(item.sizeBytes)} • ${item.totalChunks} دفعة"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                if (item.hasSplitWarning) {
                    Text(
                        text = "تنبيه: هذا التطبيق متعدد الحزم (Split APK)؛ سيتم إرسال ملف APK الأساسي.",
                        style = MaterialTheme.typography.labelMedium,
                        color = HotspotAmber,
                        fontSize = 11.sp
                    )
                }
            }
        }
        IconButton(onClick = onRemove) {
            Icon(
                imageVector = Icons.Filled.DeleteOutline,
                contentDescription = "حذف الملف",
                tint = CoralRose
            )
        }
    }
}

@Composable
fun ReceiveFilesScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onCodeChanged: (String) -> Unit,
    onConnectWithCode: (String) -> Unit,
    onConnectDiscoveredPeer: (DiscoveredPeerSession) -> Unit,
    onConfirmReceive: () -> Unit,
    onCancelReceive: () -> Unit,
    onOpenQrScanner: () -> Unit,
    onOpenReceivedApks: () -> Unit = {},
    onSelectTransportMode: (TransportMode) -> Unit = {},
    onStartBluetoothDiscovery: () -> Unit = {},
    onPairBluetoothDevice: (BluetoothPeerDevice) -> Unit = {},
    onConnectBluetoothPeer: (BluetoothPeerDevice) -> Unit = {},
    onOpenBluetoothSettings: () -> Unit = {},
    onBluetoothPermissionsResult: (Map<String, Boolean>) -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val scrollState = rememberScrollState()

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            ScreenTopBar(
                title = "استلام ملفات • برق sher",
                subtitle = "اكتشاف تلقائي أو ربط بالكود / QR مع مصادقة وموافقة المرسل",
                accentColor = NeonEmerald,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Real Connection Diagnostic Error Banner if direct connection fails
            uiState.receiverDiagnosticError?.let { diagError ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF2D0C16))
                        .border(1.2.dp, CoralRose, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                        .testTag("receiver_diagnostic_error_card")
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = CoralRose,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تشخيص تعذر الاتصال المباشر:",
                                style = MaterialTheme.typography.titleMedium,
                                color = CoralRose,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = diagError,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White
                        )
                        Text(
                            text = "💡 طرق الربط المباشر المدعومة بدون إنترنت:\n1. اتصال الجهازين بنفس شبكة Wi-Fi المحلية.\n2. أو تشغيل نقطة اتصال الهواتف (Wi-Fi Hotspot) في أحد الجهازين والاتصال بها من الجهاز الآخر ثم إعادة المحاولة.",
                            style = MaterialTheme.typography.labelMedium,
                            color = HotspotAmber
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            BluetoothAndTransportModeCard(
                uiState = uiState,
                isReceiveScreen = true,
                onSelectTransportMode = onSelectTransportMode,
                onStartBluetoothDiscovery = onStartBluetoothDiscovery,
                onPairBluetoothDevice = onPairBluetoothDevice,
                onConnectBluetoothPeer = onConnectBluetoothPeer,
                onOpenBluetoothSettings = onOpenBluetoothSettings,
                onBluetoothPermissionsResult = onBluetoothPermissionsResult
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Auto-Discovered Active Senders on the local network (UDP Discovery)
            if (uiState.discoveredPeers.isNotEmpty()) {
                Text(
                    text = "أجهزة مرسلة نشطة تم اكتشافها على الشبكة:",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonEmerald
                )
                Spacer(modifier = Modifier.height(8.dp))
                uiState.discoveredPeers.forEach { peer ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0B2520))
                            .border(1.2.dp, NeonEmerald, RoundedCornerShape(16.dp))
                            .clickable { onConnectDiscoveredPeer(peer) }
                            .padding(14.dp)
                            .testTag("discovered_peer_${peer.sessionCode}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Radar, contentDescription = null, tint = NeonEmerald, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${peer.deviceName} (${peer.sessionCode})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${peer.fileCount} ملفات • ${formatBytesArabic(peer.totalBytes)} • ${peer.hostIp}:${peer.port}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ElectricCyan
                                )
                            }
                        }
                        Button(
                            onClick = { onConnectDiscoveredPeer(peer) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("اتصال", color = Color(0xFF002418), fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Code Input Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(MidnightSurface)
                    .border(1.2.dp, NeonEmerald.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "أدخل كود الاتصال الظاهر في الهاتف المرسل",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Text(
                        text = "يدعم الكود القصير (مثل BRQ-4301) أو العنوان المباشر (IP:Port#Code)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = uiState.enteredReceiveCode,
                        onValueChange = onCodeChanged,
                        placeholder = {
                            Text(
                                text = "أدخل الكود هنا (مثال: BRQ-4301)",
                                fontFamily = JetBrainsMonoFontFamily,
                                color = TextSecondary,
                                fontSize = 14.sp
                            )
                        },
                        textStyle = TextStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            color = NeonEmerald,
                            textAlign = TextAlign.Center
                        ),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonEmerald,
                            unfocusedBorderColor = GlassBorder,
                            focusedContainerColor = Color(0xFF070E1B),
                            unfocusedContainerColor = Color(0xFF070E1B)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("receive_code_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onConnectWithCode(uiState.enteredReceiveCode) },
                        enabled = !uiState.isConnectingToSender,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("connect_by_code_button")
                    ) {
                        if (uiState.isConnectingToSender) {
                            CircularProgressIndicator(
                                color = Color(0xFF002418),
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "جاري البحث والتحقق من جلسة المرسل...",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF002418),
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Link,
                                contentDescription = null,
                                tint = Color(0xFF002418)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ربط والتحقق من جلسة الإرسال",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF002418),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // QR Code Scanner Option Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(MidnightCard)
                    .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan.copy(alpha = 0.16f))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.QrCodeScanner,
                            contentDescription = "ماسح رمز QR",
                            tint = ElectricCyan,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "مسح رمز QR Code من الهاتف المرسل",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Text(
                        text = "يتضمن رمز الـ QR عنوان الـ IP والمنفذ وكود الجلسة وتوقيت الصلاحية للاتصال الآمن الفوري",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onOpenQrScanner,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("open_qr_scanner_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = null,
                            tint = Color(0xFF002229)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "فتح الكاميرا لمسح رمز QR",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF002229),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Direct Storage & SHA-256 Info Card + Quick Button to Received APKs
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0B1526))
                    .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "📁 الحفظ والتحقق الآمن: بعد إرسال طلب الاتصال وموافقة المرسل، يتم تنزيل الملفات والمجلدات ببنيتها الأصلية في (Downloads/BarqSher) مع فحص البصمة الرقمية (SHA-256) لكل ملف.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    OutlinedButton(
                        onClick = onOpenReceivedApks,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("receive_open_received_apks_button")
                    ) {
                        Icon(Icons.Filled.Android, contentDescription = null, tint = NeonEmerald, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "فتح صفحة التطبيقات المستلمة وتثبيت APK (${uiState.receivedApks.size})",
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        CopyrightFooter()
    }

    // Confirmation Dialog displaying session info, incoming files, and sender approval status before starting transfer
    if (uiState.showReceiveConfirmationDialog && uiState.pendingIncomingFiles.isNotEmpty()) {
        val isWaitingSenderApproval =
            uiState.receiverConnectionPhase == ReceiverConnectionPhase.WAITING_SENDER_APPROVAL
        AlertDialog(
            onDismissRequest = onCancelReceive,
            containerColor = MidnightCardElevated,
            title = {
                Column {
                    Text(
                        text = "معاينة جلسة الإرسال وتأكيد الاستلام",
                        style = MaterialTheme.typography.titleLarge,
                        color = NeonEmerald,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "المرسِل: ${uiState.remoteSenderDeviceName} • الجلسة: ${uiState.remoteSessionId}",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "عدد العناصر: ${uiState.pendingIncomingFiles.size} • الإجمالي: ${formatBytesArabic(uiState.pendingTotalBytes)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ElectricCyan
                    )
                    if (uiState.pendingFolderNames.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "📁 مجلدات كاملة سيتم إعادة إنشائها ببنيتها الأصلية: ${uiState.pendingFolderNames.joinToString(" ، ")}",
                            style = MaterialTheme.typography.labelMedium,
                            color = HotspotAmber
                        )
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (isWaitingSenderApproval) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0A2924))
                                .border(1.dp, NeonEmerald, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                                .testTag("waiting_sender_approval_box")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    color = NeonEmerald,
                                    strokeWidth = 2.5.dp,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "تم إرسال طلب الاتصال إلى «${uiState.remoteSenderDeviceName}» — بانتظار موافقة المرسِل لبدء النقل الفعلي...",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = NeonEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .testTag("receive_confirmation_files_list")
                    ) {
                        items(uiState.pendingIncomingFiles, key = { it.id }) { file ->
                            val badgeColor = Color(file.category.badgeColorHex)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MidnightCard)
                                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                                    .padding(10.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(badgeColor.copy(alpha = 0.2f))
                                ) {
                                    Icon(
                                        imageVector = categoryIcon(file.category),
                                        contentDescription = file.category.arabicLabel,
                                        tint = badgeColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = file.displayPathOrName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (file.isDirectory) {
                                            "مجلد فرعي فارغ داخل (${file.rootFolderName})"
                                        } else {
                                            "${file.category.arabicLabel} (${file.fileExtensionBadge}) • ${formatBytesArabic(file.sizeBytes)}"
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onConfirmReceive,
                    enabled = !isWaitingSenderApproval,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("confirm_receive_files_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF002418),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isWaitingSenderApproval) {
                            "بانتظار موافقة المرسِل..."
                        } else {
                            "إرسال طلب الاتصال والاستلام"
                        },
                        color = Color(0xFF002418),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = onCancelReceive,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("cancel_receive_files_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = null,
                        tint = CoralRose,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إلغاء",
                        color = CoralRose,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }
}

@Composable
fun QrScannerScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onQrDetected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var manualScannedCode by remember { mutableStateOf("") }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    val laserTransition = rememberInfiniteTransition(label = "laser_scan")
    val laserOffsetFraction by laserTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            ScreenTopBar(
                title = "مسح رمز QR • برق sher",
                subtitle = "وجّه الكاميرا نحو رمز QR في الهاتف المرسل للتحقق من الجلسة والربط",
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF050A14))
                    .border(2.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
            ) {
                if (hasCameraPermission) {
                    val hasDispatchedScan = remember { AtomicBoolean(false) }
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                val analysisExecutor = Executors.newSingleThreadExecutor()
                                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                cameraProviderFuture.addListener({
                                    try {
                                        val provider = cameraProviderFuture.get()
                                        val preview = Preview.Builder().build().also {
                                            it.setSurfaceProvider(surfaceProvider)
                                        }
                                        val imageAnalysis = ImageAnalysis.Builder()
                                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                            .build()
                                            .also { analysis ->
                                                analysis.setAnalyzer(analysisExecutor) { imageProxy ->
                                                    try {
                                                        if (!hasDispatchedScan.get() && imageProxy.planes.isNotEmpty()) {
                                                            val yPlane = imageProxy.planes[0]
                                                            val buffer = yPlane.buffer
                                                            val yBytes = ByteArray(buffer.remaining())
                                                            buffer.get(yBytes)
                                                            val decoded = QrCodeGenerator.tryDecodeLumaFrame(
                                                                yPlane = yBytes,
                                                                width = imageProxy.width,
                                                                height = imageProxy.height,
                                                                rowStride = yPlane.rowStride
                                                            )
                                                            if (!decoded.isNullOrBlank() &&
                                                                hasDispatchedScan.compareAndSet(false, true)
                                                            ) {
                                                                ContextCompat.getMainExecutor(ctx).execute {
                                                                    onQrDetected(decoded)
                                                                }
                                                            }
                                                        }
                                                    } catch (_: Throwable) {
                                                    } finally {
                                                        imageProxy.close()
                                                    }
                                                }
                                            }
                                        provider.unbindAll()
                                        provider.bindToLifecycle(
                                            lifecycleOwner,
                                            CameraSelector.DEFAULT_BACK_CAMERA,
                                            preview,
                                            imageAnalysis
                                        )
                                    } catch (_: Exception) {
                                    }
                                }, ContextCompat.getMainExecutor(ctx))
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "يلزم إذن الكاميرا لمسح رمز QR من الجوال المرسل",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "نستخدم الكاميرا فقط لقراءة بيانات جلسة الاتصال المحلية (IP والمنفذ ومعرّف الجلسة) دون حفظ أي صور.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                            modifier = Modifier.testTag("grant_camera_permission_button")
                        ) {
                            Text("السماح باستخدام الكاميرا", color = Color(0xFF002229), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val frameSize = size.minDimension * 0.68f
                    val left = (size.width - frameSize) / 2f
                    val top = (size.height - frameSize) / 2f
                    val laserY = top + frameSize * laserOffsetFraction

                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, ElectricCyan, NeonEmerald, Color.Transparent)
                        ),
                        start = Offset(left, laserY),
                        end = Offset(left + frameSize, laserY),
                        strokeWidth = 4.dp.toPx()
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick connect to any discovered active sender on the network right from QR screen
            if (uiState.discoveredPeers.isNotEmpty()) {
                val firstPeer = uiState.discoveredPeers.first()
                OutlinedButton(
                    onClick = {
                        onQrDetected("BARQP2P|${firstPeer.sessionCode}|${firstPeer.hostIp}|${firstPeer.port}")
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("qr_connect_discovered_peer_button")
                ) {
                    Icon(Icons.Filled.Radar, contentDescription = null, tint = NeonEmerald, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ربط فوري بالمرسل المكتشف: ${firstPeer.deviceName} (${firstPeer.sessionCode})",
                        color = NeonEmerald,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = manualScannedCode,
                    onValueChange = { manualScannedCode = it },
                    placeholder = { Text("أو الصق بيانات QR / الكود (BRQ-XXXX)", fontSize = 13.sp) },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                val pasted = cb?.primaryClip?.getItemAt(0)?.text?.toString()?.trim().orEmpty()
                                if (pasted.isNotEmpty()) {
                                    manualScannedCode = pasted
                                }
                            },
                            modifier = Modifier.testTag("qr_paste_clipboard_button")
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "لصق من الحافظة", tint = ElectricCyan)
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("qr_manual_payload_input")
                )
                Button(
                    onClick = { onQrDetected(manualScannedCode) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("qr_manual_connect_button")
                ) {
                    Text("تحقق وربط", color = Color(0xFF002418), fontWeight = FontWeight.Bold)
                }
            }
        }

        CopyrightFooter()
    }
}

@Composable
fun ScreenTopBar(
    title: String,
    subtitle: String,
    accentColor: Color,
    onBack: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightCard)
                .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                .testTag("navigate_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "رجوع",
                tint = accentColor
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BluetoothAndTransportModeCard(
    uiState: P2PUiState,
    isReceiveScreen: Boolean,
    onSelectTransportMode: (TransportMode) -> Unit,
    onStartBluetoothDiscovery: () -> Unit,
    onPairBluetoothDevice: (BluetoothPeerDevice) -> Unit,
    onConnectBluetoothPeer: (BluetoothPeerDevice) -> Unit,
    onOpenBluetoothSettings: () -> Unit,
    onBluetoothPermissionsResult: (Map<String, Boolean>) -> Unit
) {
    val context = LocalContext.current
    val btPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        onBluetoothPermissionsResult(result)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightCard)
            .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            .padding(14.dp)
            .testTag("bluetooth_and_transport_mode_card")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (uiState.bluetoothState == BluetoothState.CONNECTED) {
                            Icons.Filled.BluetoothConnected
                        } else if (uiState.bluetoothState == BluetoothState.SCANNING) {
                            Icons.Filled.BluetoothSearching
                        } else {
                            Icons.Filled.Bluetooth
                        },
                        contentDescription = "البلوتوث ووضع النقل",
                        tint = ElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "وضع الاتصال والبلوتوث المحلي",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = ElectricCyan.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Text(
                        text = uiState.bluetoothState.arabicLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                            .testTag("bluetooth_state_badge")
                    )
                }
            }

            // Transport Mode Chips (AUTO_SMART, WIFI_HOTSPOT, BLUETOOTH_DIRECT)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                TransportMode.entries.forEach { mode ->
                    val selected = uiState.transportMode == mode
                    Surface(
                        color = if (selected) ElectricCyan.copy(alpha = 0.22f) else MidnightSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) ElectricCyan else GlassBorder
                        ),
                        modifier = Modifier
                            .clickable { onSelectTransportMode(mode) }
                            .testTag("transport_mode_chip_${mode.name}")
                    ) {
                        Text(
                            text = mode.arabicTitle,
                            fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) ElectricCyan else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Text(
                text = uiState.transportMode.arabicSubtitle,
                style = MaterialTheme.typography.labelSmall,
                color = if (uiState.transportMode == TransportMode.BLUETOOTH_DIRECT) HotspotAmber else TextSecondary
            )

            // Bluetooth Discovery & Settings Buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        if (BluetoothP2PManager.hasBluetoothPermissions(context)) {
                            onStartBluetoothDiscovery()
                        } else {
                            btPermissionsLauncher.launch(BluetoothP2PManager.requiredPermissions())
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("bluetooth_scan_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.BluetoothSearching,
                        contentDescription = null,
                        tint = Color(0xFF002229),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (uiState.bluetoothState == BluetoothState.SCANNING) {
                            "جاري البحث..."
                        } else {
                            "بحث واقتران بلوتوث"
                        },
                        color = Color(0xFF002229),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onOpenBluetoothSettings,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .height(40.dp)
                        .testTag("bluetooth_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = null,
                        tint = HotspotAmber,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إعدادات البلوتوث", color = Color.White, fontSize = 11.sp)
                }
            }

            // Discovered / Paired Bluetooth Peers List
            if (uiState.bluetoothPeers.isNotEmpty()) {
                Text(
                    text = "الأجهزة القريبة والمقترنة عبر البلوتوث (${uiState.bluetoothPeers.size}):",
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonEmerald,
                    fontWeight = FontWeight.Bold
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    uiState.bluetoothPeers.take(6).forEach { peer ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MidnightSurface)
                                .border(
                                    1.dp,
                                    if (peer.isPaired) NeonEmerald.copy(alpha = 0.5f) else GlassBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("bluetooth_peer_row_${peer.address}")
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = peer.displayName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${peer.address} • ${if (peer.isPaired) "مقترن" else "غير مقترن"}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = if (peer.isPaired) NeonEmerald else TextSecondary
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (!peer.isPaired) {
                                    Surface(
                                        color = HotspotAmber.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .border(1.dp, HotspotAmber, RoundedCornerShape(8.dp))
                                            .clickable { onPairBluetoothDevice(peer) }
                                    ) {
                                        Text(
                                            text = "اقتران",
                                            fontSize = 10.sp,
                                            color = HotspotAmber,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                                if (isReceiveScreen) {
                                    Surface(
                                        color = NeonEmerald,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .clickable { onConnectBluetoothPeer(peer) }
                                            .testTag("bt_connect_peer_${peer.address}")
                                    ) {
                                        Text(
                                            text = "اتصال واستلام",
                                            fontSize = 10.sp,
                                            color = Color(0xFF002418),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

