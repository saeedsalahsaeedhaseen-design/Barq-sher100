package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.FileTransferStatus
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.network.PeerJsWebPortalHtml
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.components.formatSpeedArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PUiState

@Composable
fun LiveTransferScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onTogglePauseResume: () -> Unit,
    onCancelTransfer: () -> Unit,
    onRestartTransfer: () -> Unit,
    onCancelSingleFile: (String) -> Unit = {},
    onToggleSingleFilePauseResume: (String) -> Unit = {},
    onAddFilesToActiveSession: (List<Uri>) -> Unit = {},
    onApproveReceiver: () -> Unit = {},
    onRejectReceiver: () -> Unit = {},
    onOpenReceivedApks: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val addMoreFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            onAddFilesToActiveSession(uris)
        }
    }

    val animatedOverallProgress by animateFloatAsState(
        targetValue = uiState.overallProgressFraction,
        animationSpec = tween(250),
        label = "overall_progress"
    )
    val overallPercent = (animatedOverallProgress * 100f).toInt().coerceIn(0, 100)
    val activeFile = uiState.activeTransferringFile

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            ScreenTopBar(
                title = "النقل الحي • برق sher",
                subtitle = uiState.connectedPeerLabel,
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Compact High-Clarity Live Telemetry Dashboard (leaves maximum vertical height for the file list)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF092235),
                                MidnightSurface,
                                Color(0xFF08241C)
                            )
                        )
                    )
                    .border(
                        width = 1.2.dp,
                        brush = Brush.horizontalGradient(listOf(ElectricCyan, NeonEmerald)),
                        shape = RoundedCornerShape(18.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .testTag("live_speed_telemetry_card")
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = uiState.transferDirection.arabicTitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NeonEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    color = if (uiState.isBackgroundServiceActive || uiState.isTransferRunning) {
                                        NeonEmerald.copy(alpha = 0.18f)
                                    } else {
                                        ElectricCyan.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.testTag("background_continuity_badge")
                                ) {
                                    Text(
                                        text = if (uiState.isTransferRunning || uiState.isBackgroundServiceActive) {
                                            "⚡ مستمر بالخلفية وعند إطفاء الشاشة"
                                        } else {
                                            "جاهز للنقل"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = if (uiState.isTransferRunning || uiState.isBackgroundServiceActive) NeonEmerald else ElectricCyan,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Speed,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = formatSpeedArabic(uiState.liveOverallSpeedBytesPerSec),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = ElectricCyan,
                                    modifier = Modifier.testTag("live_mbps_speed_text")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "المتوسط: ${formatSpeedArabic(uiState.averageSpeedBytesPerSec)} • الذروة: ${formatSpeedArabic(uiState.peakSpeedBytesPerSec)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.testTag("live_avg_and_peak_speed_text")
                                )
                            }
                        }

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF07101E))
                                .border(1.8.dp, NeonEmerald, CircleShape)
                        ) {
                            Text(
                                text = "$overallPercent%",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White,
                                modifier = Modifier.testTag("live_overall_percent_text")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { animatedOverallProgress },
                        color = ElectricCyan,
                        trackColor = Color(0xFF070E1A),
                        strokeCap = StrokeCap.Round,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .testTag("live_overall_progress_bar")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المنقول: ${formatBytesArabic(uiState.transferredBytes)} / ${formatBytesArabic(uiState.totalBytes)}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.testTag("live_transferred_total_bytes_text")
                        )
                        Text(
                            text = "المتبقي: ${uiState.formattedEtaLabel}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("live_eta_text")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = buildString {
                                append("الملفات المكتملة: ${uiState.completedFilesOnlyCount} / ${uiState.totalFilesOnlyCount}")
                                append(" • المتبقية: ${uiState.remainingFilesOnlyCount}")
                                if (uiState.failedFilesOnlyCount > 0) {
                                    append(" • متوقفة: ${uiState.failedFilesOnlyCount}")
                                }
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 11.sp,
                            color = HotspotAmber,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.testTag("live_files_counts_summary_text")
                        )
                        Text(
                            text = "الكود: ${uiState.connectionCode}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }

                    activeFile?.let { current ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الملف الجاري الآن: ${current.displayPathOrName} (${current.progressPercent}%)",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 11.sp,
                            color = ElectricCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("live_active_file_name_text")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Compact Transfer Controls Row: Pause/Resume, Cancel Session, and Restart/Resume Failed
            val canTogglePauseOrResume = uiState.isTransferRunning ||
                uiState.isPaused ||
                (uiState.transferDirection == TransferDirection.RECEIVING &&
                    uiState.files.any { it.status == FileTransferStatus.FAILED })

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = onTogglePauseResume,
                    enabled = canTogglePauseOrResume,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isPaused) NeonEmerald else HotspotAmber
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("pause_resume_transfer_button")
                ) {
                    Icon(
                        imageVector = if (uiState.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = null,
                        tint = Color(0xFF1A1000),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isPaused) "استئناف" else "إيقاف مؤقت",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1000)
                    )
                }

                OutlinedButton(
                    onClick = onCancelTransfer,
                    enabled = uiState.isTransferRunning || uiState.isSenderReady || uiState.isPaused,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("cancel_transfer_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Cancel,
                        contentDescription = null,
                        tint = CoralRose,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إلغاء النقل",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = CoralRose
                    )
                }

                OutlinedButton(
                    onClick = onRestartTransfer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("restart_transfer_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Replay,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إعادة / إكمال",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            if (uiState.transferDirection == TransferDirection.SENDING) {
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = { addMoreFilesLauncher.launch("*/*") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("add_files_to_active_session_button")
                ) {
                    Text(
                        text = "➕ إضافة ملفات جديدة إلى جلسة النقل النشطة",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val hasApkInSession = uiState.files.any { it.name.endsWith(".apk", ignoreCase = true) }
            if (hasApkInSession || uiState.receivedApks.isNotEmpty()) {
                Button(
                    onClick = onOpenReceivedApks,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("open_received_apks_from_live_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Android,
                        contentDescription = null,
                        tint = Color(0xFF002418),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "فتح التطبيقات المستلمة وتثبيت حزم APK (${uiState.receivedApks.size})",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFF002418),
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Compact Folder Transfer Summary Banner when transferring whole folder(s)
            if (uiState.activeFolderNames.isNotEmpty()) {
                val completedFilesCount = uiState.files.count { it.status == FileTransferStatus.COMPLETED }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF211709))
                        .border(1.dp, HotspotAmber.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("live_folder_summary_card")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📁 مجلد: ${uiState.activeFolderNames.joinToString(" ، ")}",
                            style = MaterialTheme.typography.labelMedium,
                            color = HotspotAmber,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$completedFilesCount / ${uiState.files.size} (${formatBytesArabic(uiState.totalBytes)})",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFFDE68A)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "قائمة الملفات الجارية (${uiState.files.size}):",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "اسحب للأعلى/الأسفل لتصفح كل الملفات",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Expanded scrollable file list occupying the majority of the screen
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("live_files_lazy_column")
            ) {
                items(uiState.files.distinctBy { it.id }, key = { it.id }) { fileItem ->
                    LiveFileProgressCard(
                        item = fileItem,
                        chunkSizeLabel = uiState.selectedChunkSize.label,
                        onTogglePauseResumeFile = { onToggleSingleFilePauseResume(fileItem.id) },
                        onCancelFile = { onCancelSingleFile(fileItem.id) }
                    )
                }
            }
        }

        CopyrightFooter()
    }

    uiState.incomingConnectionRequest?.let { req ->
        IncomingConnectionRequestDialog(
            request = req,
            onApprove = onApproveReceiver,
            onReject = onRejectReceiver
        )
    }
}

@Composable
private fun LiveFileProgressCard(
    item: TransferFileItem,
    chunkSizeLabel: String,
    onTogglePauseResumeFile: () -> Unit = {},
    onCancelFile: () -> Unit = {}
) {
    val badgeColor = Color(item.category.badgeColorHex)
    val animatedFileProgress by animateFloatAsState(
        targetValue = item.progressFraction,
        animationSpec = tween(180),
        label = "file_progress_${item.id}"
    )
    val isDone = item.status == FileTransferStatus.COMPLETED
    val isFailed = item.status == FileTransferStatus.FAILED || item.status == FileTransferStatus.CANCELLED
    val isTransferring = item.status == FileTransferStatus.TRANSFERRING || item.status == FileTransferStatus.VERIFYING

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightCard)
            .border(
                width = if (isTransferring) 1.4.dp else 1.dp,
                color = when {
                    isDone -> NeonEmerald.copy(alpha = 0.7f)
                    isFailed -> CoralRose.copy(alpha = 0.7f)
                    isTransferring -> ElectricCyan.copy(alpha = 0.8f)
                    else -> GlassBorder
                },
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("live_file_card_${item.id}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(badgeColor.copy(alpha = 0.18f))
                    ) {
                        Icon(
                            imageVector = when {
                                isDone -> Icons.Filled.CheckCircle
                                isFailed -> Icons.Filled.ErrorOutline
                                else -> categoryIcon(item.category)
                            },
                            contentDescription = item.category.arabicLabel,
                            tint = when {
                                isDone -> NeonEmerald
                                isFailed -> CoralRose
                                else -> badgeColor
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.displayPathOrName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (item.isDirectory) {
                                "مجلد فرعي • ${item.status.arabicLabel}"
                            } else {
                                "${item.category.arabicLabel} • ${item.status.arabicLabel} • ${item.progressPercent}%"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                isDone -> NeonEmerald
                                isFailed -> CoralRose
                                isTransferring -> ElectricCyan
                                else -> TextSecondary
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = when {
                            isDone -> NeonEmerald.copy(alpha = 0.18f)
                            isFailed -> CoralRose.copy(alpha = 0.18f)
                            else -> ElectricCyan.copy(alpha = 0.16f)
                        },
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Text(
                            text = when {
                                isDone -> "اكتمل 100%"
                                isFailed -> "${item.progressPercent}% • ${item.status.arabicLabel}"
                                item.currentSpeedBytesPerSec > 0.0 -> "${item.progressPercent}% • ${formatSpeedArabic(item.currentSpeedBytesPerSec)}"
                                else -> "${item.progressPercent}%"
                            },
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = when {
                                isDone -> NeonEmerald
                                isFailed -> CoralRose
                                else -> ElectricCyan
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (!isDone && item.status != FileTransferStatus.CANCELLED) {
                        val isPausedItem = item.status == FileTransferStatus.PAUSED
                        val pauseBtnColor = if (isPausedItem) NeonEmerald else HotspotAmber
                        Surface(
                            onClick = onTogglePauseResumeFile,
                            color = pauseBtnColor.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.testTag("pause_resume_single_file_${item.id}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPausedItem) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                    contentDescription = if (isPausedItem) "استئناف نقل الملف" else "إيقاف نقل الملف مؤقتاً",
                                    tint = pauseBtnColor,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (isPausedItem) "استئناف" else "إيقاف",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = pauseBtnColor
                                )
                            }
                        }

                        Surface(
                            onClick = onCancelFile,
                            color = CoralRose.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.testTag("cancel_single_file_${item.id}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Cancel,
                                    contentDescription = "إلغاء نقل الملف",
                                    tint = CoralRose,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "إلغاء",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CoralRose
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { animatedFileProgress },
                color = when {
                    isDone -> NeonEmerald
                    isFailed -> CoralRose
                    else -> ElectricCyan
                },
                trackColor = Color(0xFF070D19),
                strokeCap = StrokeCap.Round,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
            )

            Spacer(modifier = Modifier.height(5.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الحجم: ${formatBytesArabic(item.transferredBytes)} / ${formatBytesArabic(item.sizeBytes)}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    color = Color(0xFFCBD5E1)
                )
                Text(
                    text = "الدفعات: ${item.completedChunks} / ${item.totalChunks} ($chunkSizeLabel)",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    color = HotspotAmber
                )
            }

            // SHA-256 Verification Badge
            if (item.sha256Verified || item.sha256Expected.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = if (item.sha256Verified) NeonEmerald else ElectricCyan,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    val hashPreview = (item.sha256Actual.ifBlank { item.sha256Expected }).take(14)
                    Text(
                        text = if (item.sha256Verified) {
                            "تم التحقق (SHA-256: $hashPreview...)"
                        } else {
                            "بصمة SHA-256: $hashPreview..."
                        },
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 9.sp,
                        color = if (item.sha256Verified) NeonEmerald else TextSecondary
                    )
                }
            }

            item.errorMessage?.let { err ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = err,
                    style = MaterialTheme.typography.labelSmall,
                    color = CoralRose
                )
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebRtcPeerJsPortalScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var filePathCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val webFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        filePathCallback?.onReceiveValue(uris.toTypedArray())
        filePathCallback = null
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            ScreenTopBar(
                title = "بوابة الويب • برق sher",
                subtitle = "تعمل داخل التطبيق وعبر الرابط ${uiState.networkStatus.webPortalUrl}",
                accentColor = NeonEmerald,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
            ) {
                val htmlContent = remember(uiState.connectionCode, uiState.networkStatus.localIp) {
                    PeerJsWebPortalHtml.buildHtml(
                        defaultCode = uiState.connectionCode,
                        hostIp = uiState.networkStatus.localIp,
                        hostPort = uiState.networkStatus.port
                    )
                }

                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = true
                            settings.allowContentAccess = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            webViewClient = WebViewClient()
                            webChromeClient = object : WebChromeClient() {
                                override fun onShowFileChooser(
                                    webView: WebView?,
                                    callback: ValueCallback<Array<Uri>>?,
                                    fileChooserParams: FileChooserParams?
                                ): Boolean {
                                    filePathCallback?.onReceiveValue(null)
                                    filePathCallback = callback
                                    webFilePickerLauncher.launch(arrayOf("*/*"))
                                    return true
                                }
                            }
                            loadDataWithBaseURL(
                                uiState.networkStatus.webPortalUrl,
                                htmlContent,
                                "text/html",
                                "UTF-8",
                                null
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        CopyrightFooter()
    }
}
